
import nltk
import grpc
from fastai.text.all import *
from transformers import GPT2Tokenizer, GPT2LMHeadModel
from concurrent import futures

import HokkuService_pb2_grpc
import HokkuService_pb2


model=None
tokenizer=None


class HokkuServiceServicer(HokkuService_pb2_grpc.HokkuServiceServicer):
    def hokkumsg(self, request, context):
        global model
        global tekenizer
        line1=""
        line2=""
        line3=""

        line1,line2,line3=generate_text(request.HokkuTheme,50,model,tokenizer)

        response = HokkuService_pb2.HokkuResponse()
        response.HokkuLine1=line1
        response.HokkuLine2=line2
        response.HokkuLine3=line3

        return response

def StartServer():
    grpcServer =grpc.server(futures.ThreadPoolExecutor(max_workers=10))

    HokkuService_pb2_grpc.add_HokkuServiceServicer_to_server(HokkuServiceServicer() ,grpcServer)
    grpcServer.add_insecure_port('localhost:50051')
    grpcServer.start()
    print("Waiting")
    grpcServer.wait_for_termination()

def load_model(model_path):
    model = GPT2LMHeadModel.from_pretrained(model_path)
    return model
def load_tokenizer(tokenizer_path):
    tokenizer = GPT2Tokenizer.from_pretrained(tokenizer_path)
    return tokenizer
def generate_text(sequence, max_length, model, tokenizer):
    ids = tokenizer.encode(f'{sequence}', return_tensors='pt')

    haikuLine1 = []
    haikuLine2 = []
    haikuLine3 = []
    check = True
    count = 0
    while check:
        if (count == 100):
            check = False
        line1 = 5
        line2 = 7
        line3 = 5
        final_outputs = model.generate(
            ids,
            do_sample=True,
            max_length=max_length,
            pad_token_id=model.config.eos_token_id,
            top_k=100,
            top_p=0.95)
        for i in range(0, len(final_outputs[0])):
            syl = count_syllables(str(tokenizer.decode(final_outputs[0][i])))
            if (line1 != 0 and (line1 - syl > 0 or line1 - syl == 0)):
                line1 -= syl
                haikuLine1.append(final_outputs[0][i])
            elif (line1 == 0 and line2 != 0 and (line2 - syl > 0 or line2 - syl == 0)):
                line2 -= syl
                haikuLine2.append(final_outputs[0][i])
            elif (line1 == 0 and line2 == 0 and line3 != 0 and (line3 - syl > 0 or line3 - syl == 0)):
                line3 -= syl
                haikuLine3.append(final_outputs[0][i])
            elif (line1 == 0 and line2 == 0 and line3 == 0):
                return tokenizer.decode(haikuLine1, skip_special_tokens=True), tokenizer.decode(haikuLine2,
                                                                                                skip_special_tokens=True), tokenizer.decode(
                    haikuLine3, skip_special_tokens=True)
        count += 1
def count_syllables(word):
    return len(
        re.findall('(?!e$)[aeiouy]+', word, re.I) +
        re.findall('^[^aeiouy]*e$', word, re.I)
    )




if __name__ == '__main__':


    model_path = 'AAAModelresult3'
    model = load_model(model_path)
    tokenizer = load_tokenizer(model_path)

    StartServer()
