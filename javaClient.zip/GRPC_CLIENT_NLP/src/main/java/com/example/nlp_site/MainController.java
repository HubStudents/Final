package com.example.nlp_site;


import com.example.grpc.HokkuServiceGrpc;
import com.example.grpc.HokkuServiceOuterClass;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import jakarta.servlet.http.HttpSession;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class MainController {
    @GetMapping("/home")
    public String showHomePage(HttpSession session,Model model){
        session.removeAttribute("flag");
        if ( session.getAttribute("flag")==null){
            session.setAttribute("flag","works");
            Haiku hokku= new Haiku();
            hokku.setLine1("lazy afternoon");
            hokku.setLine2("a sprig of lavender sways");
            hokku.setLine3("as a bee takes flight");
            model.addAttribute("hokku",hokku);
        }
        session.removeAttribute("flag");
        return "index";
    }


    @PostMapping("/home")
    public String sendInfo(Model model, String headerInput,HttpSession session){
        ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:50051")
                .usePlaintext().build();

        HokkuServiceGrpc.HokkuServiceBlockingStub stub = HokkuServiceGrpc.
                newBlockingStub(channel);

        HokkuServiceOuterClass.HokkuRequest request = HokkuServiceOuterClass.HokkuRequest
                .newBuilder().setHokkuTheme(headerInput).build();

        HokkuServiceOuterClass.HokkuResponse response= stub.hokkumsg(request);
        Haiku hokku =new Haiku();
        hokku.setLine1(response.getHokkuLine1());
        hokku.setLine2(response.getHokkuLine2());
        hokku.setLine3(response.getHokkuLine3());

        model.addAttribute("hokku",hokku);

        return "index";
    }

}
