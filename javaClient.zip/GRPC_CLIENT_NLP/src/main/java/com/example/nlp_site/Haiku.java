package com.example.nlp_site;

public class Haiku {
    String line1;
    String line2;
    String line3;

    public void setLine1(String line){
        line1=line;
    }
    public void setLine2(String line){
        line2=line;
    }
    public void setLine3(String line){
        line3=line;
    }

    public String getLine1(){
        return line1;
    }
    public String getLine2(){
        return line2;
    }
    public String getLine3(){
        return line3;
    }
}
