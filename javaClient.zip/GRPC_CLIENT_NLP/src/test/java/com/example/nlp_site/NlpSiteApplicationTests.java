package com.example.nlp_site;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NlpSiteApplicationTests {

    @Test
    void contextLoads() {
    }

}
